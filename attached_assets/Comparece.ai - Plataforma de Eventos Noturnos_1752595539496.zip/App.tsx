import image_ff100f031b48568c5f43f350f9d97a3242cecbb2 from 'figma:asset/ff100f031b48568c5f43f350f9d97a3242cecbb2.png';
import { useState } from 'react';
import { EventExplorer } from './components/EventExplorer';
import { EventDetail } from './components/EventDetail';
import { CheckInInterface } from './components/CheckInInterface';
import { AdminDashboard } from './components/AdminDashboard';
import { Button } from './components/ui/button';
import { Card } from './components/ui/card';
import { Music, Home, Settings, User, Calendar } from 'lucide-react';
import logoImage from 'figma:asset/09ed0b3b10d9a12b6704fda62ac76b72365f32a8.png';

export default function App() {
  const [currentView, setCurrentView] = useState<'home' | 'event' | 'checkin' | 'admin'>('home');
  const [selectedEvent, setSelectedEvent] = useState<any>(null);
  const [userRole, setUserRole] = useState<'user' | 'admin' | 'staff'>('user');

  const handleEventSelect = (event: any) => {
    setSelectedEvent(event);
    setCurrentView('event');
  };

  const handleBackToHome = () => {
    setCurrentView('home');
    setSelectedEvent(null);
  };

  const handleCheckIn = () => {
    setCurrentView('checkin');
  };

  const renderCurrentView = () => {
    switch (currentView) {
      case 'event':
        return (
          <EventDetail
            event={selectedEvent}
            onBack={handleBackToHome}
            onCheckIn={handleCheckIn}
          />
        );
      case 'checkin':
        return (
          <CheckInInterface
            event={selectedEvent}
            onBack={() => setCurrentView('event')}
          />
        );
      case 'admin':
        return (
          <AdminDashboard
            onBack={handleBackToHome}
            userRole={userRole}
          />
        );
      default:
        return (
          <EventExplorer
            onEventSelect={handleEventSelect}
            onAdminAccess={() => setCurrentView('admin')}
          />
        );
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-[rgba(255,0,89,1)] text-primary-foreground p-4 sticky top-0 z-50">
        <div className="max-w-md mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <img 
              src={image_ff100f031b48568c5f43f350f9d97a3242cecbb2} 
              alt="Comparece.ai" 
              className="h-8 w-auto"
            />
          </div>
          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleBackToHome}
              className="text-primary-foreground hover:bg-primary/20"
            >
              <Home className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setCurrentView('admin')}
              className="text-primary-foreground hover:bg-primary/20"
            >
              <Settings className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-md mx-auto">
        {renderCurrentView()}
      </main>

      {/* Bottom Navigation */}
      {currentView === 'home' && (
        <nav className="fixed bottom-0 left-0 right-0 bg-card border-t border-border">
          <div className="max-w-md mx-auto">
            <div className="flex justify-around py-2">
              <Button
                variant="ghost"
                size="sm"
                className="flex flex-col items-center space-y-1 px-2"
              >
                <Home className="h-5 w-5" />
                <span className="text-xs">Início</span>
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="flex flex-col items-center space-y-1 px-2"
              >
                <Calendar className="h-5 w-5" />
                <span className="text-xs">Eventos</span>
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="flex flex-col items-center space-y-1 px-2"
              >
                <Music className="h-5 w-5" />
                <span className="text-xs">Música</span>
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="flex flex-col items-center space-y-1 px-2"
              >
                <User className="h-5 w-5" />
                <span className="text-xs">Perfil</span>
              </Button>
            </div>
          </div>
        </nav>
      )}
    </div>
  );
}