import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { ArrowLeft, QrCode, Check, X, User, Gift, Clock } from 'lucide-react';

interface Event {
  id: string;
  title: string;
  date: string;
  time: string;
  location: string;
  benefits: string[];
}

interface CheckInInterfaceProps {
  event: Event;
  onBack: () => void;
}

interface CheckInRecord {
  id: string;
  userName: string;
  checkInTime: string;
  status: 'pending' | 'validated' | 'used';
  benefits: string[];
}

const mockCheckIns: CheckInRecord[] = [
  {
    id: 'CHK001',
    userName: 'Maria Silva',
    checkInTime: '22:15',
    status: 'pending',
    benefits: ['Nome na lista', 'Desconto de 20%', 'Brinde especial']
  },
  {
    id: 'CHK002',
    userName: 'João Santos',
    checkInTime: '22:30',
    status: 'validated',
    benefits: ['Lista VIP', 'Drink grátis']
  },
  {
    id: 'CHK003',
    userName: 'Ana Costa',
    checkInTime: '22:45',
    status: 'used',
    benefits: ['Entrada gratuita', 'Área VIP']
  }
];

export function CheckInInterface({ event, onBack }: CheckInInterfaceProps) {
  const [checkIns, setCheckIns] = useState<CheckInRecord[]>(mockCheckIns);
  const [qrCode, setQrCode] = useState('');
  const [isScanning, setIsScanning] = useState(false);

  const handleQRScan = () => {
    setIsScanning(true);
    // Simular scan de QR code
    setTimeout(() => {
      const newCheckIn: CheckInRecord = {
        id: `CHK${String(checkIns.length + 1).padStart(3, '0')}`,
        userName: 'Novo Usuário',
        checkInTime: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
        status: 'pending',
        benefits: event.benefits
      };
      setCheckIns([newCheckIn, ...checkIns]);
      setIsScanning(false);
      setQrCode('');
    }, 2000);
  };

  const handleManualEntry = () => {
    if (qrCode.trim()) {
      const newCheckIn: CheckInRecord = {
        id: qrCode,
        userName: 'Usuário Manual',
        checkInTime: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
        status: 'pending',
        benefits: event.benefits
      };
      setCheckIns([newCheckIn, ...checkIns]);
      setQrCode('');
    }
  };

  const updateCheckInStatus = (id: string, status: 'validated' | 'used') => {
    setCheckIns(checkIns.map(checkIn => 
      checkIn.id === id ? { ...checkIn, status } : checkIn
    ));
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-500';
      case 'validated': return 'bg-green-500';
      case 'used': return 'bg-gray-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'pending': return 'Pendente';
      case 'validated': return 'Validado';
      case 'used': return 'Usado';
      default: return 'Desconhecido';
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-background/95 backdrop-blur-sm border-b border-border">
        <div className="flex items-center justify-between p-4">
          <Button variant="ghost" size="sm" onClick={onBack}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Voltar
          </Button>
          <Badge variant="outline">Staff Interface</Badge>
        </div>
      </div>

      <div className="p-4 space-y-6">
        {/* Event Info */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Clock className="h-5 w-5 text-primary" />
              <span>Check-in: {event.title}</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-3 gap-4 text-center">
              <div>
                <div className="text-2xl font-bold text-green-600">
                  {checkIns.filter(c => c.status === 'validated').length}
                </div>
                <div className="text-sm text-muted-foreground">Validados</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-yellow-600">
                  {checkIns.filter(c => c.status === 'pending').length}
                </div>
                <div className="text-sm text-muted-foreground">Pendentes</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-gray-600">
                  {checkIns.filter(c => c.status === 'used').length}
                </div>
                <div className="text-sm text-muted-foreground">Usados</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Scanner */}
        <Card>
          <CardHeader>
            <CardTitle>Novo Check-in</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex space-x-2">
              <Input
                placeholder="Digite ou escaneie o código QR"
                value={qrCode}
                onChange={(e) => setQrCode(e.target.value)}
                disabled={isScanning}
              />
              <Button 
                onClick={handleQRScan}
                disabled={isScanning}
                className="bg-secondary hover:bg-secondary/90"
              >
                {isScanning ? (
                  <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent" />
                ) : (
                  <QrCode className="h-4 w-4" />
                )}
              </Button>
            </div>
            
            {qrCode && (
              <Button 
                onClick={handleManualEntry}
                className="w-full"
                variant="outline"
              >
                Confirmar Check-in Manual
              </Button>
            )}

            {isScanning && (
              <div className="text-center py-4">
                <div className="text-secondary font-medium">Escaneando QR Code...</div>
                <div className="text-sm text-muted-foreground">Posicione o código na câmera</div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Check-ins List */}
        <Card>
          <CardHeader>
            <CardTitle>Check-ins Recentes</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {checkIns.map((checkIn) => (
                <div key={checkIn.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="relative">
                      <User className="h-8 w-8 text-muted-foreground" />
                      <Badge 
                        className={`absolute -top-1 -right-1 text-xs ${getStatusColor(checkIn.status)}`}
                      >
                        {getStatusText(checkIn.status)}
                      </Badge>
                    </div>
                    <div>
                      <div className="font-medium">{checkIn.userName}</div>
                      <div className="text-sm text-muted-foreground">
                        {checkIn.checkInTime} • {checkIn.id}
                      </div>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {checkIn.benefits.map((benefit, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {benefit}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex space-x-2">
                    {checkIn.status === 'pending' && (
                      <Button
                        size="sm"
                        onClick={() => updateCheckInStatus(checkIn.id, 'validated')}
                        className="bg-green-600 hover:bg-green-700"
                      >
                        <Check className="h-3 w-3" />
                      </Button>
                    )}
                    {checkIn.status === 'validated' && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => updateCheckInStatus(checkIn.id, 'used')}
                      >
                        <Gift className="h-3 w-3 mr-1" />
                        Usar
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}