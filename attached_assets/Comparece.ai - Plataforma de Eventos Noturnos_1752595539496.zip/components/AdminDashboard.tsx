import { useState } from "react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Badge } from "./ui/badge";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "./ui/tabs";
import {
  ArrowLeft,
  Plus,
  BarChart3,
  Calendar,
  Users,
  Gift,
  Settings,
  Eye,
  Edit,
  Trash2,
} from "lucide-react";

interface AdminDashboardProps {
  onBack: () => void;
  userRole: "user" | "admin" | "staff";
}

interface EventStats {
  id: string;
  title: string;
  date: string;
  views: number;
  reactions: number;
  checkIns: number;
  conversion: number;
}

const mockStats: EventStats[] = [
  {
    id: "1",
    title: "Noite do Pagode",
    date: "2025-07-18",
    views: 1234,
    reactions: 156,
    checkIns: 89,
    conversion: 57,
  },
  {
    id: "2",
    title: "Sertanejo Universitário",
    date: "2025-07-19",
    views: 2156,
    reactions: 234,
    checkIns: 145,
    conversion: 62,
  },
  {
    id: "3",
    title: "Techno Night",
    date: "2025-07-20",
    views: 876,
    reactions: 89,
    checkIns: 67,
    conversion: 75,
  },
];

export function AdminDashboard({
  onBack,
  userRole,
}: AdminDashboardProps) {
  const [stats] = useState<EventStats[]>(mockStats);
  const [isCreatingEvent, setIsCreatingEvent] = useState(false);
  const [newEvent, setNewEvent] = useState({
    title: "",
    date: "",
    time: "",
    location: "",
    description: "",
    category: "pagode",
    benefits: "",
  });

  const handleCreateEvent = () => {
    // Aqui seria criado o evento
    console.log("Criando evento:", newEvent);
    setIsCreatingEvent(false);
    setNewEvent({
      title: "",
      date: "",
      time: "",
      location: "",
      description: "",
      category: "pagode",
      benefits: "",
    });
  };

  const totalViews = stats.reduce(
    (sum, stat) => sum + stat.views,
    0,
  );
  const totalReactions = stats.reduce(
    (sum, stat) => sum + stat.reactions,
    0,
  );
  const totalCheckIns = stats.reduce(
    (sum, stat) => sum + stat.checkIns,
    0,
  );
  const avgConversion =
    stats.reduce((sum, stat) => sum + stat.conversion, 0) /
    stats.length;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-background/95 backdrop-blur-sm border-b border-border">
        <div className="flex items-center justify-between p-4">
          <Button variant="ghost" size="sm" onClick={onBack}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Voltar
          </Button>
          <Badge variant="outline">
            {userRole === "admin"
              ? "Admin"
              : userRole === "staff"
                ? "Staff"
                : "Usuário"}
          </Badge>
        </div>
      </div>

      <div className="p-4">
        <Tabs defaultValue="stats" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="stats">
              <BarChart3 className="h-4 w-4 mr-2" />
              Estatísticas
            </TabsTrigger>
            <TabsTrigger value="events">
              <Calendar className="h-4 w-4 mr-2" />
              Eventos
            </TabsTrigger>
            <TabsTrigger value="settings">
              <Settings className="h-4 w-4 mr-2" />
              Configurações
            </TabsTrigger>
          </TabsList>

          <TabsContent value="stats" className="space-y-6">
            {/* Overview Cards */}
            <div className="grid grid-cols-2 gap-4">
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-2">
                    <Eye className="h-5 w-5 text-blue-500" />
                    <div>
                      <div className="text-2xl font-bold">
                        {totalViews.toLocaleString()}
                      </div>
                      <div className="text-sm text-muted-foreground">
                        Visualizações
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-2">
                    <Users className="h-5 w-5 text-green-500" />
                    <div>
                      <div className="text-2xl font-bold">
                        {totalReactions}
                      </div>
                      <div className="text-sm text-muted-foreground">
                        Reações
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-2">
                    <Calendar className="h-5 w-5 text-purple-500" />
                    <div>
                      <div className="text-2xl font-bold">
                        {totalCheckIns}
                      </div>
                      <div className="text-sm text-muted-foreground">
                        Check-ins
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-2">
                    <BarChart3 className="h-5 w-5 text-orange-500" />
                    <div>
                      <div className="text-2xl font-bold">
                        {avgConversion.toFixed(1)}%
                      </div>
                      <div className="text-sm text-muted-foreground">
                        Conversão
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Event Performance */}
            <Card>
              <CardHeader>
                <CardTitle>Performance dos Eventos</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {stats.map((stat) => (
                    <div
                      key={stat.id}
                      className="flex items-center justify-between p-3 border rounded-lg"
                    >
                      <div>
                        <div className="font-medium">
                          {stat.title}
                        </div>
                        <div className="text-sm text-muted-foreground">
                          {stat.date}
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-sm">
                          <span className="font-medium">
                            {stat.checkIns}
                          </span>{" "}
                          check-ins
                        </div>
                        <div className="text-sm text-green-600">
                          {stat.conversion}% conversão
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="events" className="space-y-6">
            {/* Create Event Button */}
            <Card>
              <CardContent className="p-4">
                <Button
                  onClick={() => setIsCreatingEvent(true)}
                  className="w-full bg-secondary hover:bg-secondary/90"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Criar Novo Evento
                </Button>
              </CardContent>
            </Card>

            {/* Create Event Form */}
            {isCreatingEvent && (
              <Card>
                <CardHeader>
                  <CardTitle>Criar Novo Evento</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Input
                    placeholder="Título do evento"
                    value={newEvent.title}
                    onChange={(e) =>
                      setNewEvent({
                        ...newEvent,
                        title: e.target.value,
                      })
                    }
                  />
                  <div className="grid grid-cols-2 gap-2">
                    <Input
                      type="date"
                      value={newEvent.date}
                      onChange={(e) =>
                        setNewEvent({
                          ...newEvent,
                          date: e.target.value,
                        })
                      }
                    />
                    <Input
                      type="time"
                      value={newEvent.time}
                      onChange={(e) =>
                        setNewEvent({
                          ...newEvent,
                          time: e.target.value,
                        })
                      }
                    />
                  </div>
                  <Input
                    placeholder="Local do evento"
                    value={newEvent.location}
                    onChange={(e) =>
                      setNewEvent({
                        ...newEvent,
                        location: e.target.value,
                      })
                    }
                  />
                  <Textarea
                    placeholder="Descrição do evento"
                    value={newEvent.description}
                    onChange={(e) =>
                      setNewEvent({
                        ...newEvent,
                        description: e.target.value,
                      })
                    }
                  />
                  <Textarea
                    placeholder="Benefícios (separados por vírgula)"
                    value={newEvent.benefits}
                    onChange={(e) =>
                      setNewEvent({
                        ...newEvent,
                        benefits: e.target.value,
                      })
                    }
                  />
                  <div className="flex space-x-2">
                    <Button
                      onClick={handleCreateEvent}
                      className="flex-1"
                    >
                      Criar Evento
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => setIsCreatingEvent(false)}
                      className="flex-1"
                    >
                      Cancelar
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Events List */}
            <Card>
              <CardHeader>
                <CardTitle>Eventos Criados</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {stats.map((stat) => (
                    <div
                      key={stat.id}
                      className="flex items-center justify-between p-3 border rounded-lg"
                    >
                      <div>
                        <div className="font-medium">
                          {stat.title}
                        </div>
                        <div className="text-sm text-muted-foreground">
                          {stat.date} • {stat.views}{" "}
                          visualizações
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        <Button variant="ghost" size="sm">
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>
                  Configurações do Estabelecimento
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2">
                    Nome do Estabelecimento
                  </label>
                  <Input placeholder="Bar do Zé" />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">
                    Endereço
                  </label>
                  <Input placeholder="Rua das Flores, 123 - Centro" />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">
                    Telefone
                  </label>
                  <Input placeholder="(11) 99999-9999" />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">
                    Categoria Principal
                  </label>
                  <select className="w-full p-2 border rounded-lg">
                    <option>Pagode</option>
                    <option>Sertanejo</option>
                    <option>Techno</option>
                    <option>Funk</option>
                  </select>
                </div>
                <Button className="w-full">
                  Salvar Configurações
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Gerenciar Equipe</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <div className="font-medium">
                        João Silva
                      </div>
                      <div className="text-sm text-muted-foreground">
                        Funcionário
                      </div>
                    </div>
                    <Badge>Ativo</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <div className="font-medium">
                        Maria Santos
                      </div>
                      <div className="text-sm text-muted-foreground">
                        Promoter
                      </div>
                    </div>
                    <Badge>Ativo</Badge>
                  </div>
                  <Button variant="outline" className="w-full">
                    <Plus className="h-4 w-4 mr-2" />
                    Adicionar Membro
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}