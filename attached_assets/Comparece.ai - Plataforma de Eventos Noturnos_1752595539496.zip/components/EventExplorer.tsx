import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { MapPin, Clock, Users, Heart, ThumbsUp, X } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface Event {
  id: string;
  title: string;
  date: string;
  time: string;
  location: string;
  category: string;
  image: string;
  description: string;
  attendees: number;
  reactions: {
    going: number;
    thinking: number;
    notGoing: number;
  };
  benefits: string[];
}

interface EventExplorerProps {
  onEventSelect: (event: Event) => void;
  onAdminAccess: () => void;
}

const musicCategories = [
  { id: 'pagode', name: 'Pagode', icon: '🎺', color: 'bg-red-500' },
  { id: 'sertanejo', name: 'Sertanejo', icon: '🤠', color: 'bg-yellow-500' },
  { id: 'techno', name: 'Techno', icon: '🎛️', color: 'bg-purple-500' },
  { id: 'funk', name: 'Funk', icon: '🎤', color: 'bg-green-500' },
  { id: 'rock', name: 'Rock', icon: '🎸', color: 'bg-orange-500' },
  { id: 'pop', name: 'Pop', icon: '🎵', color: 'bg-pink-500' },
  { id: 'reggae', name: 'Reggae', icon: '🌿', color: 'bg-green-600' },
  { id: 'eletronica', name: 'Eletrônica', icon: '🎧', color: 'bg-blue-500' },
];

const mockEvents: Event[] = [
  {
    id: '1',
    title: 'Noite do Pagode - Turma do Pagode',
    date: '2025-07-18',
    time: '22:00',
    location: 'Bar do Zé - Centro',
    category: 'pagode',
    image: 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=400&h=300&fit=crop',
    description: 'Uma noite especial com muito pagode e diversão!',
    attendees: 156,
    reactions: { going: 89, thinking: 45, notGoing: 22 },
    benefits: ['Nome na lista', 'Desconto de 20% no couvert', 'Brinde especial']
  },
  {
    id: '2',
    title: 'Sertanejo Universitário - Live Show',
    date: '2025-07-19',
    time: '21:30',
    location: 'Arena Music - Zona Sul',
    category: 'sertanejo',
    image: 'https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=400&h=300&fit=crop',
    description: 'Os maiores sucessos do sertanejo universitário!',
    attendees: 234,
    reactions: { going: 145, thinking: 67, notGoing: 22 },
    benefits: ['Lista VIP', 'Desconto no bar', 'Acesso prioritário']
  },
  {
    id: '3',
    title: 'Techno Night - DJ Set Underground',
    date: '2025-07-20',
    time: '23:00',
    location: 'Club Seven - Bairro Novo',
    category: 'techno',
    image: 'https://images.unsplash.com/photo-1571266028243-4fdf9f43b60c?w=400&h=300&fit=crop',
    description: 'Noite techno com os melhores DJs da cidade!',
    attendees: 89,
    reactions: { going: 67, thinking: 15, notGoing: 7 },
    benefits: ['Entrada gratuita', 'Drink especial', 'Área VIP']
  },
  {
    id: '4',
    title: 'Funk Ostentação - Baile do Fim de Semana',
    date: '2025-07-21',
    time: '20:00',
    location: 'Quadra da Vila - Periferia',
    category: 'funk',
    image: 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=400&h=300&fit=crop',
    description: 'O melhor funk da cidade com MC convidados!',
    attendees: 345,
    reactions: { going: 267, thinking: 45, notGoing: 33 },
    benefits: ['Entrada VIP', 'Cerveja grátis', 'Foto com os MCs']
  }
];

export function EventExplorer({ onEventSelect, onAdminAccess }: EventExplorerProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [userReactions, setUserReactions] = useState<Record<string, 'going' | 'thinking' | 'notGoing' | null>>({});

  const filteredEvents = selectedCategory === 'all' 
    ? mockEvents 
    : mockEvents.filter(event => event.category === selectedCategory);

  const handleReaction = (eventId: string, reaction: 'going' | 'thinking' | 'notGoing') => {
    setUserReactions(prev => ({
      ...prev,
      [eventId]: prev[eventId] === reaction ? null : reaction
    }));
  };

  const getReactionIcon = (type: 'going' | 'thinking' | 'notGoing') => {
    switch (type) {
      case 'going':
        return '✅';
      case 'thinking':
        return '🤔';
      case 'notGoing':
        return '❌';
    }
  };

  return (
    <div className="p-4 pb-20">
      {/* Hero Section */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold mb-2">Onde vou comparecer?</h1>
        <p className="text-muted-foreground">Escolha seu estilo e descubra os melhores eventos</p>
      </div>

      {/* Category Filter */}
      <div className="mb-6">
        <div className="flex space-x-2 overflow-x-auto pb-2">
          <Button
            variant={selectedCategory === 'all' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setSelectedCategory('all')}
            className="whitespace-nowrap"
          >
            Todos
          </Button>
          {musicCategories.map(category => (
            <Button
              key={category.id}
              variant={selectedCategory === category.id ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSelectedCategory(category.id)}
              className="whitespace-nowrap"
            >
              <span className="mr-1">{category.icon}</span>
              {category.name}
            </Button>
          ))}
        </div>
      </div>

      {/* Events Grid */}
      <div className="space-y-4">
        {filteredEvents.map(event => (
          <Card key={event.id} className="overflow-hidden hover:shadow-lg transition-shadow">
            <div className="relative">
              <ImageWithFallback
                src={event.image}
                alt={event.title}
                className="w-full h-48 object-cover"
              />
              <div className="absolute top-2 right-2">
                <Badge className="bg-primary text-primary-foreground">
                  {musicCategories.find(cat => cat.id === event.category)?.icon} {musicCategories.find(cat => cat.id === event.category)?.name}
                </Badge>
              </div>
            </div>
            
            <CardContent className="p-4">
              <div className="mb-3">
                <h3 className="font-semibold mb-1">{event.title}</h3>
                <div className="flex items-center text-sm text-muted-foreground space-x-3">
                  <span className="flex items-center">
                    <Clock className="h-3 w-3 mr-1" />
                    {event.time}
                  </span>
                  <span className="flex items-center">
                    <MapPin className="h-3 w-3 mr-1" />
                    {event.location}
                  </span>
                  <span className="flex items-center">
                    <Users className="h-3 w-3 mr-1" />
                    {event.attendees}
                  </span>
                </div>
              </div>

              {/* Benefits */}
              <div className="mb-3">
                <div className="flex flex-wrap gap-1">
                  {event.benefits.map((benefit, index) => (
                    <Badge key={index} variant="outline" className="text-xs">
                      {benefit}
                    </Badge>
                  ))}
                </div>
              </div>

              {/* Reactions */}
              <div className="flex items-center justify-between">
                <div className="flex space-x-2">
                  <Button
                    variant={userReactions[event.id] === 'going' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => handleReaction(event.id, 'going')}
                    className="flex items-center space-x-1"
                  >
                    <span>✅</span>
                    <span className="text-xs">EU VOU</span>
                    <span className="text-xs">({event.reactions.going})</span>
                  </Button>
                  <Button
                    variant={userReactions[event.id] === 'thinking' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => handleReaction(event.id, 'thinking')}
                    className="flex items-center space-x-1"
                  >
                    <span>🤔</span>
                    <span className="text-xs">PENSANDO</span>
                    <span className="text-xs">({event.reactions.thinking})</span>
                  </Button>
                </div>
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={() => onEventSelect(event)}
                >
                  Ver Detalhes
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Admin Access Button */}
      <div className="mt-8 pt-4 border-t border-border">
        <Button
          variant="outline"
          size="sm"
          onClick={onAdminAccess}
          className="w-full"
        >
          Acesso Estabelecimento / Admin
        </Button>
      </div>
    </div>
  );
}