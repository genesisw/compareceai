import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { ArrowLeft, MapPin, Clock, Users, Gift, QrCode, Share2, Heart } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface Event {
  id: string;
  title: string;
  date: string;
  time: string;
  location: string;
  category: string;
  image: string;
  description: string;
  attendees: number;
  reactions: {
    going: number;
    thinking: number;
    notGoing: number;
  };
  benefits: string[];
}

interface EventDetailProps {
  event: Event;
  onBack: () => void;
  onCheckIn: () => void;
}

export function EventDetail({ event, onBack, onCheckIn }: EventDetailProps) {
  const [userReaction, setUserReaction] = useState<'going' | 'thinking' | 'notGoing' | null>(null);
  const [hasGeneratedQR, setHasGeneratedQR] = useState(false);

  const handleReaction = (reaction: 'going' | 'thinking' | 'notGoing') => {
    setUserReaction(userReaction === reaction ? null : reaction);
  };

  const handleGenerateQR = () => {
    setHasGeneratedQR(true);
    // Aqui seria gerado o QR code real
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-background/95 backdrop-blur-sm border-b border-border">
        <div className="flex items-center justify-between p-4">
          <Button variant="ghost" size="sm" onClick={onBack}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Voltar
          </Button>
          <Button variant="ghost" size="sm">
            <Share2 className="h-4 w-4 mr-2" />
            Compartilhar
          </Button>
        </div>
      </div>

      {/* Event Image */}
      <div className="relative">
        <ImageWithFallback
          src={event.image}
          alt={event.title}
          className="w-full h-64 object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
        <div className="absolute bottom-4 left-4 right-4 text-white">
          <h1 className="text-2xl font-bold mb-2">{event.title}</h1>
          <div className="flex items-center space-x-4 text-sm">
            <span className="flex items-center">
              <Clock className="h-4 w-4 mr-1" />
              {formatDate(event.date)} às {event.time}
            </span>
          </div>
        </div>
      </div>

      <div className="p-4 space-y-6">
        {/* Event Info */}
        <Card>
          <CardContent className="p-4">
            <div className="space-y-3">
              <div className="flex items-center space-x-2">
                <MapPin className="h-5 w-5 text-muted-foreground" />
                <span>{event.location}</span>
              </div>
              <div className="flex items-center space-x-2">
                <Users className="h-5 w-5 text-muted-foreground" />
                <span>{event.attendees} pessoas interessadas</span>
              </div>
              <div className="pt-2">
                <p className="text-muted-foreground">{event.description}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Benefits */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Gift className="h-5 w-5 text-secondary" />
              <span>Benefícios para quem comparece</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {event.benefits.map((benefit, index) => (
              <div key={index} className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-secondary rounded-full" />
                <span>{benefit}</span>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Reactions */}
        <Card>
          <CardHeader>
            <CardTitle>Sua reação</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-3">
              <Button
                variant={userReaction === 'going' ? 'default' : 'outline'}
                onClick={() => handleReaction('going')}
                className="flex items-center space-x-2"
              >
                <span>✅</span>
                <div className="text-left">
                  <div className="font-medium">EU VOU</div>
                  <div className="text-xs text-muted-foreground">{event.reactions.going} pessoas</div>
                </div>
              </Button>
              <Button
                variant={userReaction === 'thinking' ? 'default' : 'outline'}
                onClick={() => handleReaction('thinking')}
                className="flex items-center space-x-2"
              >
                <span>🤔</span>
                <div className="text-left">
                  <div className="font-medium">PENSANDO</div>
                  <div className="text-xs text-muted-foreground">{event.reactions.thinking} pessoas</div>
                </div>
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Check-in Section */}
        {userReaction === 'going' && (
          <Card className="border-secondary">
            <CardHeader>
              <CardTitle className="text-secondary">Pronto para comparecer?</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <p className="text-sm text-muted-foreground">
                Gere seu QR code para check-in no evento e garanta todos os benefícios!
              </p>
              
              {!hasGeneratedQR ? (
                <Button 
                  onClick={handleGenerateQR}
                  className="w-full bg-secondary hover:bg-secondary/90"
                >
                  <QrCode className="h-4 w-4 mr-2" />
                  Gerar QR Code de Check-in
                </Button>
              ) : (
                <div className="space-y-3">
                  <div className="bg-white p-4 rounded-lg border text-center">
                    <div className="w-32 h-32 bg-black mx-auto mb-2 flex items-center justify-center text-white">
                      <QrCode className="h-16 w-16" />
                    </div>
                    <p className="text-sm font-medium">Seu QR Code</p>
                    <p className="text-xs text-muted-foreground">#{event.id}-USER123</p>
                  </div>
                  <Button 
                    onClick={onCheckIn}
                    variant="outline"
                    className="w-full"
                  >
                    Ver Interface de Check-in
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Call to Action */}
        {!userReaction && (
          <div className="text-center py-6">
            <p className="text-muted-foreground mb-4">
              Marque sua presença para garantir os benefícios!
            </p>
            <Button 
              onClick={() => handleReaction('going')}
              size="lg"
              className="bg-secondary hover:bg-secondary/90"
            >
              ✅ EU VOU COMPARECER
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}